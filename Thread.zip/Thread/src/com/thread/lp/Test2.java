package com.thread.lp;

public class Test2 {

	public static void main(String[] args) {

		Thread t1 = new Thread();
		t1.start();
		for(int i =0 ;i<10 ;i++){	
			System.out.println("main------"+i);
		}
	}

}
