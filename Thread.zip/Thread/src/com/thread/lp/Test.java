package com.thread.lp;

public class Test {

	public static void main(String[] args) {
		
		
		TestTherad thread = new TestTherad();
		thread.run();
	}

}
