package com.thread.lp;

public class Test4 {

	public static void main(String[] args) {
		
		Thread4 t1=new Thread4("first");
		Thread4 t2=new Thread4("sconed");
		t1.start();
		t2.start();
		// TODO Auto-generated method stub

//		Thread4 t1 = new Thread4();
//		t1.start();
//		try {
//			t1.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		for(int j=0; j<5;j++){
//			System.out.println("main---"+j);
//			
//		}

		
	}

}
