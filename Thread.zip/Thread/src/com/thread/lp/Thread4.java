package com.thread.lp;

public class Thread4 extends Thread{

	
	
	public Thread4( String name ){
		super(name);
	}
	@Override
	public void run() {
		
		for(int i = 0 ;i<5;i++){
			System.out.println(getName()+"--"+i);
			if(i%2==0){
				yield();//当i为偶数时，该线程就会把cpu时间让掉，让其他或者自己的线程执行，谁先抢到谁先执行		
			}
		}
	}
}
