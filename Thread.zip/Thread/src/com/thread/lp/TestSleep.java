package com.thread.lp;

import java.util.Date;

public class TestSleep extends Thread{
	public boolean flag= true;
	 
	@Override
	public void run() {
		while(flag){
			System.out.println("--"+new Date());
			 try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return;
					}
		}
		 
	}

}
