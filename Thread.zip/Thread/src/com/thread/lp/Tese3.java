package com.thread.lp;

public class Tese3 {

	public static void main(String[] args) {
		
		TestSleep t1 = new TestSleep();
		
		t1.start();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	t1.flag = false;
	}	

}
