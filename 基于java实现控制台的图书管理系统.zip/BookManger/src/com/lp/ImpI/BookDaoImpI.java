package com.lp.ImpI;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.lp.pojo.Book;
import com.lp.pojo.BookDao;
import com.lp.util.JdbcUtils;

public class BookDaoImpI implements BookDao{
	Scanner scanner = new Scanner(System.in);

	@Override
	public void addBook() {
		System.out.println("�������鼮id��");
		int bid= scanner.nextInt();
		
		System.out.println("�������鼮��ţ�");
		String bn = scanner.next();
		
		System.out.println("�������鼮���ƣ�");
		String bname = scanner.next();
		
		System. out.println("�������鼮�۸�");
		double price =Double.parseDouble(scanner.next());
		
		System.out.println("�������鼮���ߣ�");
		String author= scanner.next();
		
		System.out.println("�������鼮�����磺");
		String publisher= scanner.next();
		
		System.out.println("�������鼮�������ڣ�(yyyy-MM-dd)");
		SimpleDateFormat  sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date date = null;
		try {
			
			date = sdf.parse(scanner.next());
			
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			System.out.println("���������ʽ����,�˳���ǰ��������");
			addBook();
		}
		
		
		System.out.println("�������鼮״̬��(--1:�ϼ�||2���¼�--)");
		String lended= scanner.next();
		
		System.out.println("�������鼮������");
		int count= scanner.nextInt();
		
		Book book = new Book(bid, bn, bname, price, author, publisher, date, lended, count);
	
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet rs = null;
		con = JdbcUtils.getConnection();
		String sql = "insert into tb_book value(?,?,?,?,?,?,?,?,?)";
	
		try {
			pre= con.prepareStatement(sql);
			pre.setInt(1, book.getBookid());
			pre.setString(2, book.getIsbn());
			pre.setString(3, book.getBname());
			pre.setDouble(4, book.getPrice());
			pre.setString(5, book.getAuthor());
			pre.setString(6, book.getPublisher());
			pre.setDate(7,(new java.sql.Date(book.getPubdate().getTime())));	
			pre.setString(8, book.getLended());
			pre.setInt(9, book.getCounter());
			pre.executeUpdate();
			System.out.println("���ӳɹ�");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

	@Override
	public void lendBook(int bid,int rid) {
		
		Connection con = null;
		PreparedStatement pre = null;
		PreparedStatement pre2 = null;
		Statement st = null;
		Statement st2 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		con = JdbcUtils.getConnection();
		String sql = "update tb_book set counter=counter+? where bookid=?";
		
		try {
			String sql2 ="select * from tb_book";
			st = con.createStatement();
			rs = st.executeQuery(sql2);
			
			int bookid = 0 ;
			int counter = 0;
			//int count
			int [] arr =new int [10];
			
			int i =0,j=0;
			
			while(rs.next()){
				 bookid = rs.getInt(1);
				 counter = rs.getInt(9);
				 arr[i]=bookid;
				 i++;
			}
			Boolean flag = false;
			for(i=0;i<arr.length;i++){
			if(bid==arr[i]){
				flag = true;
				try {
					pre= con.prepareStatement(sql);
					pre.setDouble(1, -1);
					pre.setInt(2, bid);
					pre.executeUpdate();
					break;
	} catch (SQLException e1) {
		
	}
			}
			}
			if(flag){
				System.out.println("����ɹ�����");
				String sql3 ="insert into tb_record value(null,?,?,?,null,?)";
				
				st2 = con.createStatement();
				//rs2 = st2.executeQuery(sql3);
				pre2=con.prepareStatement(sql3);
				pre2.setInt(1, bid);
				pre2.setInt(2, rid);
				Date d = new Date();
				SimpleDateFormat  sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				pre2.setString(3, sdf.format(d));
				pre2.setDouble(4, 0);
				pre2.executeUpdate();
			}else{
				System.out.println("ͼ����޴��飬����ʧ�ܣ���");
			}
						
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
				
	@Override
	public void backBook(int bookid,int readerid) {
		Connection con = null;
		PreparedStatement pre = null;
		PreparedStatement pre2 = null;
		ResultSet rs = null;
		Statement st = null;
		Statement st2 = null;
		con = JdbcUtils.getConnection();
		String sql = "update tb_book set counter=counter+? where bookid=?";
		String sql2 = "select * from tb_book";
		int id = 0 ;
		int counter = 0;
		//int count
		int [] arr =new int [10];
		int i =0;
		try {
			st = con.createStatement();
			rs = st.executeQuery(sql2);
			while(rs.next()){
				 id = rs.getInt(1);
				 counter = rs.getInt(9);
				 arr[i]=id;
				 i++;
			}
			Boolean flag = false;
			for(i=0;i<arr.length;i++){
			if(bookid==arr[i]){
				flag = true;
					pre= con.prepareStatement(sql);
					pre.setDouble(1, 1);
					pre.setInt(2, bookid);
					pre.executeUpdate();
					break;
		}
			
			}
			if(flag){
				System.out.println("����ɹ�����");
				String sql3 ="update tb_record set backdate=?,publishment=? where bid=? and rid=?";
				String sql4 = "SELECT lenddate FROM tb_record WHERE bid='"+bookid+"'and rid='"+readerid+"'";
				Statement st3 = con.createStatement();
				ResultSet rs3 = st3.executeQuery(sql4);
				rs3.next();
				Date d3 = new Date();
				d3 = rs3.getDate("lenddate");
				long time = d3.getTime();
				
				st2 = con.createStatement();
				//rs2 = st2.executeQuery(sql3);
				pre2=con.prepareStatement(sql3);
				pre2.setInt(3, bookid);
				pre2.setInt(4, readerid);
				Date d2 = new Date();
				SimpleDateFormat  sdf2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				pre2.setString(1, sdf2.format(d2));
				long time2 = d2.getTime();
				long t = (time2-time)/(24*60*60*1000);
				System.out.println("�������Ϊ��"+t);
				double pub = t*1.2;
				pre2.setDouble(2, pub);
				pre2.executeUpdate();
				
			}else{
				System.out.println("���鲻���ڣ�����ʧ�ܣ���");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void updateBook(String bookid,int lend) {
		Connection con = null;
		PreparedStatement pre = null;
		ResultSet rs = null;
		con = JdbcUtils.getConnection();
		String sql = "update tb_book set lended=? where bookid=?";
		try {
			pre= con.prepareStatement(sql);
			pre.setInt(1, lend);
			pre.setString(2, bookid);
		    if (lend==0) {
		    	 System.out.println("�鼮���¼�");
			}else if(lend==1){
				 System.out.println("�鼮���ϼ�");
			}
		    pre.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}



}
