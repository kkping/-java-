package com.lp.test;

import java.util.Scanner;


import com.lp.ImpI.ReaderDaoImpI;
import com.lp.pojo.ReaderDao;

public class Test {


	public static void main(String[] args) {
		
	
		ReaderDao readerDao = new ReaderDaoImpI();
		Scanner scanner = new Scanner(System.in);
		System.out.println("�������û�����");
		String rname = scanner.next();
		System.out.println("�������û�id��");
		int readerid = scanner.nextInt();
		readerDao.login(rname,readerid);	
		readerDao.menu();
		
	}
}
