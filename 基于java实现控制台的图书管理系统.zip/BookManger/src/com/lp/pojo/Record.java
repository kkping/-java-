package com.lp.pojo;

import java.sql.Date;

public class Record {

	private int recordid;
	private String rname;
	private String gender;
	private String tel;
	private String bname;
	private Date lenddate;
	private Date backdate;
	private Double publishment;
	public int getRecordid() {
		return recordid;
	}
	public void setRecordid(int recordid) {
		this.recordid = recordid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public Date getLenddate() {
		return lenddate;
	}
	public void setLenddate(Date lenddate) {
		this.lenddate = lenddate;
	}
	public Date getBackdate() {
		return backdate;
	}
	public void setBackdate(Date backdate) {
		this.backdate = backdate;
	}
	public Double getPublishment() {
		return publishment;
	}
	public void setPublishment(Double publishment) {
		this.publishment = publishment;
	}
	@Override
	public String toString() {
		return "����id��" + recordid + "\t������" + rname + "\t�Ա�" + gender + "\t�绰���룺" + tel + "\t�����鼮������"
				+ bname + "\t����ʱ��=" + lenddate + "\t�黹���ڣ�" + backdate + "\t���" + publishment ;
	}
	public Record() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Record(int recordid, String rname, String gender, String tel, String bname, Date lenddate, Date backdate,
			Double publishment) {
		super();
		this.recordid = recordid;
		this.rname = rname;
		this.gender = gender;
		this.tel = tel;
		this.bname = bname;
		this.lenddate = lenddate;
		this.backdate = backdate;
		this.publishment = publishment;
	}
	
	
	
}
