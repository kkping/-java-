package com.lp.pojo;

import java.util.Date;

public class Book {

	private int bookid;
	private String isbn;
	private String bname;
	private double price;
	private String author;
	private String publisher;
	private Date  pubdate;
	private String lended;
	private int counter;
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public Date getPubdate() {
		return pubdate;
	}
	public void setPubdate(Date pubdate) {
		this.pubdate = pubdate;
	}
	public String getLended() {
		return lended;
	}
	public void setLended(String lended) {
		this.lended = lended;
	}
	public int getCounter() {
		return counter;
	}
	public void setCounter(int counter) {
		this.counter = counter;
	}
	public Book(int bookid, String isbn, String bname, double price, String author, String publisher, Date pubdate,
			String lended, int counter) {
		super();
		this.bookid = bookid;
		this.isbn = isbn;
		this.bname = bname;
		this.price = price;
		this.author = author;
		this.publisher = publisher;
		this.pubdate = pubdate;
		this.lended = lended;
		this.counter = counter;
	}
	
	public Book() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", isbn=" + isbn + ", bname=" + bname + ", price=" + price + ", author="
				+ author + ", publisher=" + publisher + ", pubdate=" + pubdate + ", lended=" + lended + ", counter="
				+ counter + "]";
	}
	
	
	
}
