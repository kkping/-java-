package com.lp.pojo;

import java.util.Date;

public class Reader {

	private int readerid;
	private String rname;
	private String gender;
	private String tel;
	private Date regdate;
	private int available;
	
	
	public int getReaderid() {
		return readerid;
	}
	public void setReaderid(int readerid) {
		this.readerid = readerid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public int getAvailable() {
		return available;
	}
	public void setAvailable(int available) {
		this.available = available;
	}
	@Override
	public String toString() {
		
		
		return "����id��" + readerid + "\t������" + rname + "\t�Ա�" + gender + "\t�绰���룺" + tel
				+ "\tע�����ڣ�" + regdate + "\t�Ƿ�ע��=" + this.ava(available) ;
	}
	public Reader(int readerid, String rname, String gender, String tel, Date regdate,  int available) {
		super();
		this.readerid = readerid;
		this.rname = rname;
		this.gender = gender;
		this.tel = tel;
		this.regdate=regdate;
		this.available = available;
	}
	
	public String ava(int available) {
		if(available==1){
			return "��Ч�û�";
		}
		if(available==0){
			return "��Ч�û�";
		}
		return null;
		
		
	}
	public Reader() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Reader(int readerid, String rname) {
		this.readerid= readerid;
		this.rname=rname;
	}
	
	
}
