package com.lp.pojo;

public interface BookDao {

	public void addBook();
	public void lendBook(int bookid,int readerid);
	public void backBook(int bookid,int readerid);
	public void updateBook(String bookid,int lend);
	
}