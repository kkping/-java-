package com.lp.socket;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientTCP {

	public static void main(String[] args) throws IOException {

		//while(true){
		Socket socket = new Socket("192.168.3.103", 6666);
		DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
		dataOutputStream.writeUTF("我是李小龙，我为自己带盐");
		dataOutputStream.flush();
		dataOutputStream.close();
		socket.close();
		//}
	}

}
