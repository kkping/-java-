package com.lp.socket;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class ReciveUDP {

	public static void main(String[] args) throws IOException {
	byte [] buf = new byte[1024];
	DatagramPacket datagramPacket = new DatagramPacket(buf, buf.length);
		DatagramSocket datagramSocket = new DatagramSocket(6666);
		datagramSocket.receive(datagramPacket);
		System.out.println(new String(buf,0,datagramPacket.getLength()));

	}

}
