package com.lp.socket;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerTCP {

	public static void main(String[] args) throws IOException {
		//创建对象
		ServerSocket serverSocket = new ServerSocket(6666);
		while(true){
			//将客户端和服务器端的套接字连接起来
			Socket socket = serverSocket.accept();
			//创建数据包，获得的输入流将指向客户端socket对象的输出流
			DataInputStream dataInputStream  = new DataInputStream(socket.getInputStream());
			System.out.println(dataInputStream.readUTF());
			System.out.println(socket.getInetAddress()+"--"+socket.getPort());
			dataInputStream.close();
			socket.close();
		}
	}
	
}
