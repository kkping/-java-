package com.lp.socket;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

public class SendUDP {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub

		//创建数据包
		DatagramSocket datagramSocket = new DatagramSocket();
		String str = "js";
		byte[] b = str.getBytes();
		DatagramPacket datagramPacket = new DatagramPacket(b, b.length,new InetSocketAddress("localhost", 6666));
		
		datagramSocket.send(datagramPacket);
		Thread.sleep(1000);
		datagramSocket.close();
	}

}
