package com.lp.sockettest;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class TestClient {

	public static void main(String[] args) {
		
		String [] str = {"早饭吃了吗？","中午睡觉了吗？","有女朋友吗？"};
		Socket socket = null;
		DataInputStream dataInputStream = null;
		DataOutputStream dataOutputStream = null;
		
		try {
			socket = new Socket("192.168.3.125",3369);
			dataInputStream = new DataInputStream(socket.getInputStream());
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			for (int i = 0; i < str.length; i++) {
				dataOutputStream.writeUTF(str[i]);
				System.out.println(dataInputStream.readUTF());
				Thread.sleep(1000);
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
