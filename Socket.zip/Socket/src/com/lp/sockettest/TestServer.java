package com.lp.sockettest;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class TestServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String [] string = {"吃了","睡了","还没哟"};
		
		DataInputStream dataInputStream = null;
		DataOutputStream dataOutputStream = null;
		try {
			ServerSocket serverSocket = new ServerSocket(3369);
			Socket socket = serverSocket.accept();
			dataInputStream = new DataInputStream(socket.getInputStream());
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			for (int i = 0; i < string.length; i++) {
				System.out.println(dataInputStream.readUTF());
				dataOutputStream.writeUTF(string[i]);
				Thread.sleep(1000);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
