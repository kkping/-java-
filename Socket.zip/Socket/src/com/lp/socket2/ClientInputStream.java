package com.lp.socket2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientInputStream implements Runnable{

	private Socket socket= null;
	public ClientInputStream(Socket socket) {
		super();
		this.socket = socket;
	}

	@Override
	public void run() {
			try {
				BufferedReader bufferedReader =  new BufferedReader(new InputStreamReader(socket.getInputStream()));;
	
			while(true){
				try {
					String line = bufferedReader.readLine();
					System.out.println(line);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					break;
				}
			}
			bufferedReader.close();
	}catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
}
