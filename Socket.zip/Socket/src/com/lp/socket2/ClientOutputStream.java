package com.lp.socket2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientOutputStream implements Runnable{

	private Socket socket;
	public ClientOutputStream(Socket socket) {
		super();
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			BufferedReader bufferedReader =  new BufferedReader(new InputStreamReader(System.in));;
			PrintWriter printWriter = new PrintWriter(socket.getOutputStream(),true);
		while(true){
			
				String line = bufferedReader.readLine();
				printWriter.println(line);
				if (line.equals("bye")) {
					break;
					}
				}
				bufferedReader.close();
				printWriter.close();
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	}
}
