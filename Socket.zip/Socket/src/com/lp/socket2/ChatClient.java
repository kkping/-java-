package com.lp.socket2;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class ChatClient {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub

		Socket socket = new Socket("192.168.3.125", 8888);
		new Thread(new ClientInputStream(socket)).start();
		new Thread(new ClientOutputStream(socket)).start();
	}

}
