package com.lp.socket2;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerStream implements Runnable{
	private Socket socket;
	private int num;
	
	public ServerStream(Socket socket, int num) {
		super();
		this.socket=socket;
		this.num = num;
	}
	@Override
	public void run() {
		try {
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter printWriter = new PrintWriter(socket.getOutputStream(),true);
			while(true){
				String  line = bufferedReader.readLine();
				System.out.println("客户端:"+line);
				printWriter.println(line.toUpperCase());
				if(line.equals("bye")){
					System.out.println("客户端"+num+"退出连接");
					break;
				}
			}
			bufferedReader.close();
			printWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	

}
