
public class MyThead{
    public static void main(String [] args ){
    	
    	
        int [] arr = {3,4,1,2};
        
    }
}