import java.util.Scanner;

public class Number{

public static void main(String [] args){
    
	Scanner sc = new Scanner(System.in);
    System.out.println("��������㣺");
    int start = sc.nextInt();
    System.out.println("�������յ㣺");
    int end = sc.nextInt();
   System.out.println(Count(start, end));
}
public static  int Count(int start,int end){
    
    String  num = "";
    int num2=0;
    int count=0;
    for(int i = 1;i<end;i++){
    	if (i<start) {
			num = num+i;
		}
    	if(i>=start && i<=end){
    		num = num+i;
    		//System.out.println(num);
    		num2 = Integer.parseInt(num);
    		if(num2%3==0){
    			count++;
    			}
    		}
    	}
    return count;
    }
}